﻿using MediatR;

namespace SharedKernel;

public interface IDomainEvent : INotification;
