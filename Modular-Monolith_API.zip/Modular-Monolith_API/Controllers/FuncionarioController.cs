﻿using Funcionarios.Application.Command.Add;
using Funcionarios.Application.DTOs;
using Funcionarios.Application.Query.GetByNome;
using Funcionarios.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using SharedKernel;
using System.Security.AccessControl;

namespace Modular_Monolith_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FuncionarioController : ControllerBase
    {
        private readonly IMediator _mediatR;
        public FuncionarioController(IMediator mediator)
        {
            _mediatR = mediator;
        }

        [HttpGet(Name = "GetFuncionariosByNome")]
        public async Task<ActionResult> GetByNome(string nome)
        {
            var result = (await _mediatR.Send(new GetFuncionarioByNomeQuery(nome)));
            if (result.IsSuccess)
            {
                return Ok(result.Value);
            }
            else
            {
                if (result != null && result.Error == FuncionarioErrors.NotFound(nome))
                {
                    return NotFound(result.Error);
                }
                else
                {
                    return BadRequest(result?.Error);
                }
            }
        }

        [HttpPost(Name = "AddFuncionario")]
        public async Task<ActionResult> Add(FuncionarioDTO funcionario)
        {
            var result = (await _mediatR.Send(new AddFuncionarioCommand(funcionario.nome,funcionario.idade,funcionario.email)));
            if (result.IsSuccess)
            {
                return Ok(result.Value);
            }
            else
            {
                if (result != null && result.Error == FuncionarioErrors.EmailNotUnique)
                {
                    return Conflict(result.Error);
                }
                else
                {
                    return BadRequest(result?.Error);
                }
            }
        }

    }
}
