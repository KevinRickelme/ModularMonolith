﻿using AutoMapper;
using Funcionarios.Application.DTOs;
using Funcionarios.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funcionarios.Application.Mappings
{
    public class DomainToDTOMappingProfile : Profile
    {
        public DomainToDTOMappingProfile()
        {
            CreateMap<Funcionario, FuncionarioDTO>().ReverseMap();
        }
    }
}
