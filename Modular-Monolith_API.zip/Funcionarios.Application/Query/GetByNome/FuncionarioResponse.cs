﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funcionarios.Application.Query.GetByNome
{
    public sealed record FuncionarioResponse{
        string Nome { get; init; }
        int Idade { get; init; }
        string Email { get; init; }
    }
}
