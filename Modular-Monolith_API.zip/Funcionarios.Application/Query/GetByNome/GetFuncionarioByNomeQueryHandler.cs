﻿using AutoMapper;
using Funcionarios.Application.Abstractions.Messaging;
using Funcionarios.Application.DTOs;
using Funcionarios.Domain.Abstractions;
using Funcionarios.Domain.Entities;
using MediatR;
using SharedKernel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funcionarios.Application.Query.GetByNome
{
    public class GetFuncionarioByNomeQueryHandler(IFuncionarioRepository funcionarioRepository, IMapper mapper) 
        : IQueryHandler<GetFuncionarioByNomeQuery, IEnumerable<FuncionarioDTO>>
    {
        private readonly IFuncionarioRepository _funcionarioRepository = funcionarioRepository;
        private readonly IMapper _mapper = mapper;

        public async Task<Result<IEnumerable<FuncionarioDTO>>> Handle(GetFuncionarioByNomeQuery query, CancellationToken cancellationToken)
        {
            var result = await _funcionarioRepository.GetByNomeAsync(query.nome, cancellationToken);
            if (result == null || result.Count == 0)
            {
                return Result.Failure<IEnumerable<FuncionarioDTO>>(FuncionarioErrors.NotFound(query.nome));
            }
            var funcionarioDTOs = _mapper.Map<IEnumerable<FuncionarioDTO>>(result);
            return Result.Success(funcionarioDTOs);
        }
    }
}
