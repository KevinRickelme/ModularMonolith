﻿using Funcionarios.Application.Abstractions.Messaging;
using Funcionarios.Application.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Funcionarios.Application.Query.GetByNome
{
    public sealed record GetFuncionarioByNomeQuery(string nome) : IQuery<IEnumerable<FuncionarioDTO>>;
}
