﻿namespace Funcionarios.Application.Query.GetByNome
{
    public interface IQueryHandler<T>
    {
    }
}